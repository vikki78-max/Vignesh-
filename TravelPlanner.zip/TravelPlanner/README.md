# Travel Planner (Java OOP)

Console-based Travel Planner built for **23CSR303 – Object Oriented Programming with Java, Assignment II**.

**Name:** Vignesh P
**Register No:** 717825Y158

## Features
- Build itineraries with flights and hotel bookings
- Add / remove segments
- Compute total cost (polymorphic `estimateCost()`)
- Print itinerary and day-wise plan

## OOP Concepts Demonstrated
| Concept | Where |
|---|---|
| Inheritance | `FlightSegment` and `HotelBooking` extend abstract `Segment` |
| Method overloading | `TravelService.addFlight(...)` (object vs. custom details) |
| Method overriding | `estimateCost()` / `printDetails()` in each subclass |
| Polymorphism | `Itinerary` iterates `List<Segment>` to compute totals |
| Encapsulation | Private fields and getters in `Itinerary`; defensive copy in `getSegments()` |

## Classes
- `Segment` – abstract base class
- `FlightSegment` – flight details and fare
- `HotelBooking` – hotel stay, cost = nights x nightly rate
- `Itinerary` – holds segments, total cost, dates
- `TravelService` – add/remove segments, estimate cost, print plans
- `TravelAppMain` – test driver

## Run
```bash
cd src
javac *.java
java TravelAppMain
```

## Sample Output
Total with all segments: Rs.19000.00
After removing flight AI202: Rs.13000.00
